package senser;

public class ADSBSentenceDisplay
{
	public void display(ADSBSentence message)
	{
		System.out.println(message);
	}
}
