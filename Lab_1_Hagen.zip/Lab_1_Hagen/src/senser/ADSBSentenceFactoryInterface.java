package senser;

public interface ADSBSentenceFactoryInterface
{
	public ADSBSentence fromWebdisJson(String json);
}
